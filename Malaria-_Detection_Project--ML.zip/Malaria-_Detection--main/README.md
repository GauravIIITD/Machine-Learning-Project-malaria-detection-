# Analysis of traditional and deep learning methods on Malaria Detection from Image Cells

We go through a detailed study of tradition machine learning algorithms for malaria detection. Attached Report details the analysis. 


